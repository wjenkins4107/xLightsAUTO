#!/usr/bin/env python

# Name: xlDoc.py
# Purpose: Create workbook from xLights network and rgbeffects xml files
# Author: Bill Jenkins
# Version: v1.0
# Date: 08/17/2023

#######################
### Imports         ###
#######################

import argparse
import xml.etree.ElementTree as ET
import sys
import os
import platform
import re
import datetime
import xlsxwriter

#######################
### Imports From    ###
#######################
from istools import *
from pathlib import Path

###############################
# path_exists_case_sensitive  #
###############################
def path_exists_case_sensitive(path, verbose) -> bool:
    p = Path(path)
    # If it doesn't exist initially, return False
    if not p.exists():
        if (verbose):
            print ("Initial Path not found")
        return False
    # Else loop over the path, checking each consecutive folder for
    # case sensitivity
    while True:
        if (verbose):
            print ("path = ", p)
        # At root, p == p.parent --> break loop and return True
        if p == p.parent:
            return True
        # If string representation of path is not in parent directory, return False
        if str(p) not in map(str, p.parent.iterdir()):
            if (verbose):
                print("Parent path not found")
            return False
        p = p.parent
################################
### loadwbFmtList            ###
################################

def loadwbFmtList(fname, splitCH, verbose):

    if (verbose):
        print ("loadwbFmtList: (000) *** Begin ***")

    # Open Template File
    wbFmtfile = open(fname, "r")

    # Init Lists
    wbFmtList = []

    # Init Indexes & Counters
    wbFmtIndex = 0
    wbFmtctr = 0

    wbHeaderImage = os.path.join('images', "default-image.png")

    # Filter?
    FilterSection = False

    # Read Workbook Format File
    for linex in wbFmtfile:
        wbFmtctr += 1
        line = linex.rstrip("\n")
        if (verbose):
            print ("loadwbFmtList: (010) line[%s] = %s" % (wbFmtctr, line))
        columns = line.split(splitCH)
        # Last Column Empty?
        if (len(columns[-1]) < 1):
            columns.pop()
        lencolumns = len(columns)
        if (lencolumns > 1):
            XType = columns[0]
            if (verbose):
                print ("loadwbFmtList: (020) columns = %s" % columns)
                print ("loadwbFmtList: (020) columns length = %s" % lencolumns)
            # Worksheet Format
            if XType in ["WF"]:
                workList = []
                workList.append(XType)
                workList.append(wbFmtIndex)
                for index in range(1, len(columns)):
                    workList.append(columns[index])
                wbFmtList.append(workList)
                wbFmtIndex += 1
            # Header Image
            elif XType in ["WI"]:
                wbHeaderImage = os.path.join('images', columns[1])

    # Close Template File
    wbFmtfile.close()
    #
    if (verbose):
        for index, wbFmt in enumerate(wbFmtList):
            print ("loadwbFmtList: (030) wbFmtList[%s] = %s" % (index, wbFmt))

        print ("loadwbFmtList: (030) wbFmtctr = %s" % wbFmtctr)

        print ("loadwbFmtList: (999) *** End ***")

    # Return WorkBook Format List and Header Image
    return(wbFmtList, wbHeaderImage)

####################################
### createWorkbookFormatsList    ###
####################################

def createWorkbookFormatsList(workbook, wbFmtList, verbose):

    verbose = False

    if (verbose):
        print ("createWorkbookFormatsList: (000) *** Begin ***")

    wbFormatsList = []
    wctr = 0
    for w in wbFmtList:

        stop =  len(w)

        if (verbose):
            print ("createWorkbookFormatsList: (010) wbFmtList[%s] = %s" % (wctr, w))
            print ("createWorkbookFormatsList: (010) wbFmtList[%s] length = %s" % (wctr, stop))

        namesList = []
        for i in range(2, stop, 2):
            namesList.append(w[i])
        if (verbose):
            print ("createWorkbookFormatsList: (020) namesList = %s" % namesList)

        valuesList = []
        for i in range(3, stop, 2):
            valuesList.append(w[i])
        if (verbose):
            print ("createWorkbookFormatsList: (030) valuesList = %s" % valuesList)

        names_values = zip(namesList, valuesList)

        if (verbose):
            print ("createWorkbookFormatsList: (040) names_values = %s" % names_values)


        format_dict = {}
        for name, value in names_values:
            (NumberFound, Number) = isnumber(value)
            # Number
            if (NumberFound):
                format_dict[name] = Number
            # True/False?
            elif (value.lower() == "true"):
                format_dict[name] = True
            elif (value.lower() == "false"):
                format_dict[name] = False
            # String Value
            else:
                format_dict[name] = value

        if (verbose):
            print ("createWorkbookFormatsList: (050) format_dict = %s" % format_dict)

        wbFormat = workbook.add_format(format_dict)

        wbFormatsList.append(wbFormat)

    if (verbose):
        print ("createWorkbookFormatsList: (999) *** End ***")

    return(wbFormatsList)

#########################
### wsOutput          ###
#########################
def wsOutput(worksheet, wsRow, wsCol, wsCellList, wsCellFmtList, wbFormatsList, verbose):

    if (verbose):
        print ("wsOutput: (000) *** Begin ***")
          # Workbook Format for Cell
#
    for wsCellIndex, wsCell in enumerate(wsCellList):
        if (verbose):
            print ("wsOutput: (010) , wsCellList[%s] = %s, wsRow = %s, wsCol = %s" % (wsCellIndex, wsCell, wsRow, wsCol))
        # Workbook Format for Cell
        (NumberFound, Number) = isint(wsCellFmtList[wsCellIndex])
        if (NumberFound):
            wbFmt =  wbFormatsList[Number]
        else:
            wbFmt =  wbFormatsList[0]
        # Number?
        (NumberFound, Number) = isnumber(wsCell)
        if (NumberFound):
            worksheet.write_number(wsRow, wsCol, Number, wbFmt)
        else:
            worksheet.write_string(wsRow, wsCol, wsCell, wbFmt)       
        # Increment Column
        wsCol += 1
    if (verbose):
        print ("wsOutput: (000) *** End ***")

#########################
### createWorksheet   ###
#########################

def createWorksheet(workbook, worksheetname, wspaper, wsorientation, wsmleft, wsmright, wsmtop, wsmbottom, wsrepeatrow, wsprintscale, wstitle1, wstitle2, wbHeaderImage, verbose):

    if (verbose):
        print ("createWorksheet: (000) *** Begin ***")

    # Add Worksheet
    worksheet = workbook.add_worksheet(worksheetname)

    # Worksheet Page Setup

    # Set Paper Type
    (valid, number) = isint(wspaper)
    if (valid):
        worksheet.set_paper(number)
    else:
        worksheet.set_paper(0)
    
    # Set Orientation
    if (wsorientation == "portrait"):
        worksheet.set_portrait()
    else:
        worksheet.set_landscape()

    # Set Margins
    (valid, wsmleft) = isfloat(wsmleft)
    if (valid):
        wsmleft == number
    else:
        wsmleft = 0.7
    (valid, number) = isfloat(wsmright)
    if (valid):
        wsmright = number
    else:
        wsmright = 0.7
    (valid, wsmtop) = isfloat(wsmtop)
    if (valid):
        wsmtop = number
    else:    
        wsmtop = 1.25
    (valid, bottom) = isfloat(wsmbottom)
    if (valid):
        wsmbottom = number
    else:
        wsmright = 0.7
    worksheet.set_margins(wsmleft, wsmright, wsmtop, wsmbottom)

    # Set Repeat Row
    (valid, number) = isint(wsrepeatrow)
    if (valid):
        worksheet.repeat_rows(number)

    # Set Print Scale
    (valid, number) = isint(wsprintscale)
    if (valid):
        wsprintscale = number
    else:
        wsprintscale = 100
    worksheet.set_print_scale(wsprintscale)

    # Init Header & Footer
    header = '&L&"Calibri,Bold"&D\n&T' + '&C&"Calibri,Bold"' + wstitle1 + '\n' + wstitle2 + '&R&[Picture]'
    footer = '&CPage &P of &N'

    # Set Header & Footer
    worksheet.set_header(header, {'image_right': wbHeaderImage})
    worksheet.set_footer(footer)

    if (verbose):
        print ("createWorksheet: (999) *** End ***")

    return(worksheet)


#########################
### createWorkbook    ###
#########################

def createWorkbook(workbookfile, wbFmtList, verbose):

    if (verbose):
        print ("createWorkbook: (000) *** Begin ***")

    # Create Workbook
    workbook = xlsxwriter.Workbook(workbookfile)
    # Set Workbook Properties
    workbook.set_properties({
        'title': 'xLights Controllers Documentation',
        'subject': 'XML Files',
        'author': 'Bill Jenkins',
        'manager': '',
        'company': '',
        'category': 'documentation',
        'keywords': 'xml, xLights, ,Controllers, documentation',
        'comments': ''})

    # Create Workbook Formats List
    wbFormatsList = createWorkbookFormatsList(workbook, wbFmtList, verbose)

    if (verbose):
        wbFmtctr = 0
        for wbFmt in  wbFormatsList:
            print ("createWorkbook: (010) wbFmt[%s] = %s" % (wbFmtctr, wbFmt))
            print (type(wbFmt))
            wbFmtctr += 1

    if (verbose):
        print ("createWorkbook: (999) *** End ***")

    return(workbook, wbFormatsList)

##########################
### searchNetworksXML  ###
##########################
def searchNetworksXML(workbook, wbFormatsList, wbHeaderImage, xlNetworksXmlFull, xlShowFolder, verbose):
    if (verbose):
        print ("searchXML: (000) *** Begin ***")
    #
    # Networks Tree
    #
    xNetworksTree = ET.parse(xlNetworksXmlFull)
    # Networks Root
    xNetworksRoot = xNetworksTree.getroot()
    
    # Create Worksheet for Controllers
    worksheetname = "Controllers"
    wspaper = 1
    wsorientation = "landscape"
    wsmleft = 0.7
    wsmright = 0.7
    wsmtop = 1.5
    wsmbottom = 0.7
    wsrepeatrow = "NONE"
    wsprintscale = 100
    wstitle1 = "Controllers"
    wstitle2 = "Show Folder: " + xlShowFolder
    wsPageBreak = []
    # Create Worksheet
    worksheet = createWorksheet(workbook, worksheetname, wspaper, wsorientation, wsmleft, wsmright, wsmtop, wsmbottom, wsrepeatrow, wsprintscale, wstitle1, wstitle2, wbHeaderImage, verbose)
    # Init WS Row & Col
    wsRow = 0
    wsCol = 0
    # OS Version
    wsCellList = []
    wsCellFmtList = []
    wsCellList.append("OS Platform")
    wsCellFmtList.append(3) 
    wsCellList.append(platform.platform())
    wsCellFmtList.append(0)
    wsOutput(worksheet, wsRow, wsCol, wsCellList, wsCellFmtList, wbFormatsList, verbose)
    wsRow += 1
    # Python Version
    wsCellList = []
    wsCellFmtList = []
    wsCellList.append("Python Version")
    wsCellFmtList.append(3) 
    wsCellList.append(sys.version)
    wsCellFmtList.append(0)
    wsOutput(worksheet, wsRow, wsCol, wsCellList, wsCellFmtList, wbFormatsList, verbose)
    wsRow += 1
    # Get Current Working Directory
    wsCellList = []
    wsCellFmtList = []
    wsCellList.append("Current Working Directory")
    wsCellFmtList.append(3) 
    wsCellList.append(os.getcwd())
    wsCellFmtList.append(0)
    wsOutput(worksheet, wsRow, wsCol, wsCellList, wsCellFmtList, wbFormatsList, verbose)
    wsRow += 2
    # Get Root Attributes
    networksAttrib = ([*xNetworksRoot.attrib])
    for i in range(len(networksAttrib)):
        wsCellList = []
        wsCellFmtList = []
        wsCellList.append(networksAttrib[i])
        wsCellFmtList.append(3) 
        wsCellList.append(xNetworksRoot.get(networksAttrib[i]))
        wsCellFmtList.append(0)
        wsOutput(worksheet, wsRow, wsCol, wsCellList, wsCellFmtList, wbFormatsList, verbose)   
        wsRow += 1
    # Autofit Worksheet
    worksheet.autofit()    
    # Set Controller Index
    ctlIndex = 1
    # Get Controllers
    for ctl in xNetworksRoot.findall('Controller'):
        # Get All Controller Attributes
        ctlAttrib = ([*ctl.attrib])
        # Create Worksheet for Controller
        ctlName = ctl.get("Name")
        worksheetname = ctlName
        wspaper = 1
        wsorientation = "landscape"
        wsmleft = 0.7
        wsmright = 0.7
        wsmtop = 1.5
        wsmbottom = 0.7
        wsrepeatrow = "NONE"
        wsprintscale = 100
        wstitle1 = "Controller: " + ctlName
        wstitle2 = "Show Folder: " + xlShowFolder
        wsPageBreak = []
        # Init WS Row & Col
        wsRow = 0
        wsCol = 0
        # Create Worksheet
        worksheet = createWorksheet(workbook, worksheetname, wspaper, wsorientation, wsmleft, wsmright, wsmtop, wsmbottom, wsrepeatrow, wsprintscale, wstitle1, wstitle2, wbHeaderImage, verbose)

        # Worksheet Output for Controllers 
        for i in range(len(ctlAttrib)):
            if (verbose):
                print ("%s = %s" % (ctlAttrib[i], ctl.get(ctlAttrib[i])))
            wsCellList = []
            wsCellList.append(ctlAttrib[i])
            wsCellList.append(ctl.get(ctlAttrib[i]))
            wsCellFmtList = []
            wsCellFmtList.append(3)
            wsCellFmtList.append(0)
            wsOutput(worksheet, wsRow, wsCol, wsCellList, wsCellFmtList, wbFormatsList, verbose)
            # Increment Row
            wsRow += 1
            wsCol = 0
        wsCellList = []
        wsCellFmtList = []
        wsRow += 1
        wsCol = 0
        Header = True
        # Worksheet Output for Network within Controller
        for net in ctl.findall('network'):
            # Get Controller Network Attributes
            netAttrib = ([*net.attrib])
            if (verbose):
                print ("netAttrib = ", netAttrib)
            # Network Headers
            if (Header):
                for j in range(len(netAttrib)):
                    wsHdr = netAttrib[j]
                    if (wsHdr == "BaudRate"):
                        wsHdr = "Universes/ID"
                    if (verbose):
                        print ("wsHdr = ", wsHdr)
                    wsCellList.append(wsHdr)
                    wsCellFmtList.append(3)
                wsOutput(worksheet, wsRow, wsCol, wsCellList, wsCellFmtList, wbFormatsList, verbose)
                # Set Repeat Row
                worksheet.repeat_rows(wsRow)
                Header = False
            # Network Attributes
            wsCellList = []
            wsCellFmtList = []
            wsRow += 1
            wsCol = 0
            for j in range(len(netAttrib)):
                wsCell = net.get(netAttrib[j])
                if (verbose):
                    print("wsCell = ",wsCell)
                wsCellList.append(wsCell)
                wsCellFmtList.append(0)    
            wsOutput(worksheet, wsRow, wsCol, wsCellList, wsCellFmtList, wbFormatsList, verbose)

            
        # Autofit Worksheet
        worksheet.autofit()
        # Increment ctlIndex
        ctlIndex += 1

    if (verbose):
       print ("searchXL: (999) *** End ***")

###########################
### searchRgbEffectsXML ###
###########################
def searchRgbEffectsXML(workbook, wbFormatsList, wbHeaderImage, xlRgbEffectsXmlFull, xlShowFolder, verbose):
    if (verbose):
        print ("searchRGBEffectsXML: (000) *** Begin ***")
        print ("xlRgbEffectsXmlFull = %s" % xlRgbEffectsXmlFull)
    #
    # RGB Effects Tree
    #
    xRgbEffectsTree = ET.parse(xlRgbEffectsXmlFull)
    # RGB Effects Root
    xRgbEffectsRoot = xRgbEffectsTree.getroot()

    if (verbose):
       print ("searchRGBEffectsXML: (999) *** End ***")

#########################
### main              ###
#########################

def main():


    print ("*" * 50)
    print ("main: (000) *** xlDoc Tool Begin ***")

    cli_parser = argparse.ArgumentParser(
    prog = 'xlDoc',
    description = '''%(prog)s is a tool to create a workbook file from a show folder.''')

    ### Define Arguments

    cli_parser.add_argument('-s', '--xlShowFolder', help = 'xLights Show Folder',
        required = True)

    cli_parser.add_argument('-n', '--xlNetworksXmlFile', help = 'xLights Networks XML File',default = "xlights_networks.xml",
        required = False)
        
    cli_parser.add_argument('-r', '--xlRgbEffectsXmlFile', help = 'xLights RGB Effects XML File',default = "xlights_rgbeffects.xml",
        required = False)

    cli_parser.add_argument('-w', '--wbfile', help = 'Workbook File Name',default = "DEFAULT",
        required = False)

    cli_parser.add_argument('-f', '--wbfmtfile', help = 'Workbook Format File Name',default = "DEFAULT",
        required = False)

    cli_parser.add_argument('-v', '--verbose', help = 'Verbose logging', action='store_true',
        required = False)

    ### Get Arguments

    args = cli_parser.parse_args()

    ### Current Working Directory
    CWD = os.getcwd()

    ### Verbose Logging?
    xlShowFolder = os.path.abspath(args.xlShowFolder)
    xlNetworksXmlFile = args.xlNetworksXmlFile
    xlRgbEffectsXmlFile = args.xlRgbEffectsXmlFile
    wbfile = args.wbfile
    wbfmtfile = args.wbfmtfile
    verbose = args.verbose
    if (verbose):
        print ("Xlights Show Folder = %s" % xlShowFolder)
        print ("xLights Networks XML File = %s" % xlNetworksXmlFile)
        print ("xLights RGB Effects XML File = %s" % xlRgbEffectsXmlFile)
        print ("Workbook File = %s" % wbfile)
        print ("Workbook Format File = %s" % wbfmtfile)
    # Verify Show Folder
    if not os.path.isdir(xlShowFolder):
        print("Error: xLights Show Folder not found %s" % xlShowFolder)
        sys.exit(-1)
    # Path Case Sensitive Check
    if not (path_exists_case_sensitive(xlShowFolder, verbose)):
        print("Error: xLights Show Folder case does not match %s" % xlShowFolder)
        sys.exit(-1)
    # Verify Network XML File
    xlNetworksXmlFull = xlShowFolder + "\\" + xlNetworksXmlFile
    if not os.path.isfile(xlNetworksXmlFull):
        print("Error: xLights RGB Effects XML File not found %s" % xlNetworksXmlFull)
        sys.exit(-1)
    # Verify RGB Effects XML File
    xlRgbEffectsXmlFull = xlShowFolder + "\\" + xlRgbEffectsXmlFile
    if not os.path.isfile(xlRgbEffectsXmlFull):
        print("Error: xLights RGB Effects XML File not found %s" % xlRgbEffectsXmlFull)
        sys.exit(-1)
    #
    # Workbook Format File Name
    if (wbfmtfile == "DEFAULT"):
        wbfmtfile = os.path.join('workbookformats', "default-workbookformats.txt")
    else:
        wbfmtfile = os.path.join('workbookformats', wbfmtfile)

    # Verify Workbook Format File Exists
    if not os.path.isfile(wbfmtfile):
        print ("main: (Error) Format file %s not found!\n" % wbfmtfile)
        sys.exit(-1)

    # Workbook File Name
    if (wbfile == "DEFAULT"):
        # Get Current Date Time
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
        # Workbook Name
        wbfile = os.path.join('workbooks',"xlDoc-" + timestamp + ".xlsx")
    else:
        wbfile = os.path.join('workbooks',wbfile + ".xlsx")

    # Load Workbook Formats
    if (verbose):
        print ("*" * 50)
        print ("main: (100) Begin load Workbook Format List from Workbook Format File")
    (wbFmtList, wbHeaderImage) = loadwbFmtList(wbfmtfile, ";", verbose)
    if (verbose):
        print ("main: (110) End Init Workbook Format List from Workbook Format File")

    # Create Workbook
    (workbook, wbFormatsList) = createWorkbook(wbfile, wbFmtList, verbose)

    # Search xLights Networks XML
    if (verbose):
        print ("*" * 50)
        print ("main: (110) Begin Search xLights Networks XML File")
    searchNetworksXML(workbook, wbFormatsList, wbHeaderImage, xlNetworksXmlFull, xlShowFolder, verbose)
    if (verbose):
        print ("main: (120) End Search xLights Networks XML File")
    
    # Search xLights RGB Effects XML
    if (verbose):
        print ("*" * 50)
        print ("main: (130) Begin Search xLights Networks XML File")
    searchRgbEffectsXML(workbook, wbFormatsList, wbHeaderImage, xlRgbEffectsXmlFull, xlShowFolder,  verbose)
    if (verbose):
        print ("main: (140) End Search xLights Networks XML File")
    
    # Close Workbook
    workbook.close()
    #
    print ("*" * 50)
    print ("main: (900) Created workbook: %s" % wbfile)

    print ("*" * 50)
    print ("main: (999) *** xLDoc Tool End ***")
    print ("*" * 50)


if __name__ == "__main__":
    main()

